<?php
include 'Connection.php';

if (isset($_GET['deleteid'])) {
    $id = $_GET['deleteid'];

    // Perform the deletion query
    $sql = "DELETE FROM `data` WHERE `id` = '$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        header('location:display.php');
    } else {
        die(mysqli_error($conn));
    }
}
?>
