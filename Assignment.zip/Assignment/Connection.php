<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname = "user";

$conn = mysqli_connect("localhost","root","", "user");
if(!$conn){
     die(mysqli_connect_error($conn));
}
?>